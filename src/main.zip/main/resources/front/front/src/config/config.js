export default {
    baseUrl: 'http://localhost:8080/springbootxnkj/',
    indexNav: [
        {
            name: '首页',
            url: '/index/home'
        },
        {
            name: '体检套餐',
            url: '/index/tijiantaocan'
        },
        {
            name: '公告信息',
            url: '/index/news'
        },
    ]
}
